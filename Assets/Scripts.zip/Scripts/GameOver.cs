﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class GameOver : MonoBehaviour
{
    public Text points, highscore, points_old, highscore_old;
  
    void Start()
    {
        DoAnimation("Pop Up");
        points.text = points_old.text;
        highscore.text = highscore_old.text;
        points_old.gameObject.SetActive(false);
        highscore_old.gameObject.SetActive(false);
    }

    private void DoAnimation(string v)
    {
        gameObject.GetComponent<Animator>().Play(v);
    }
}
