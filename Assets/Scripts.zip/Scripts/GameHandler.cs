﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class GameHandler : MonoBehaviour
{
    int highScore;
    public Text points, highscore;
    public GameObject gameOver;

    private void Awake()
    {
        gameOver.SetActive(false);
        highScore = PlayerPrefs.GetInt("highscore");
        highscore.text = "HighScore: " + highScore.ToString();
    }

    public void Score(int score)
    {
        points.text = "Points: " + score.ToString();
    }

    public void GameOver(int score)
    {
        if (highScore <= score)
        {
            PlayerPrefs.SetInt("highscore", score);
        }
        gameOver.SetActive(true);
    }

}
