﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Controller : MonoBehaviour
{

    public int points,jumpForce;
    public GameObject gameHandler,spawner;
    private Rigidbody2D birdRB2D;
    // Start is called before the first frame update
    void Awake()
    {
        birdRB2D = GetComponent<Rigidbody2D>();
        points = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButton(0))
            {
            Jump();
        }
       gameHandler.GetComponent<GameHandler>().Score(points++);
    }

    private void Jump()
    {
        birdRB2D.velocity = Vector2.up * jumpForce;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "KillZone")
        {
            gameHandler.GetComponent<GameHandler>().GameOver(points);
            points = 0;
            Destroy(collision.gameObject);
            Destroy(spawner);
            Destroy(gameObject);
        }


    }
}
