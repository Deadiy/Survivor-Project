﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class Spawner : MonoBehaviour
{
    public Vector2 x_range, y_range;
    public int spawnrate,move_speed = 5;
    public GameObject enemies, powerups;

    public float difficulty = 0;

    void Start()
    {
    }
    void Update()
    {
        Spawn(spawnrate);
        
    }

    private void Spawn(int spawnrate)
    {
        
        StartCoroutine(Create(spawnrate,difficulty));   
    }
    IEnumerator Create(int rate, float count)
    {
        yield return new WaitForSeconds(rate);
        if (difficulty <= 10) difficulty += Time.deltaTime * 0.05f;
        if (transform.childCount < difficulty)
        {
            GameObject a = Instantiate(enemies);
            a.transform.position = new Vector3(Random.Range(x_range.x, x_range.y), Random.Range(y_range.x, y_range.y), 0);
            a.GetComponent<ConstantForce2D>().force = new Vector2(-move_speed, 0f);
            a.transform.SetParent(transform);
        }
    }
}
